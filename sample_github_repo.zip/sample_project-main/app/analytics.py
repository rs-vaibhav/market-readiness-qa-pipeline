
def calculate_percentile(values: list, p: float) -> float:
    if not values:
        raise ValueError("Empty list")
    if not (0.0 <= p <= 100.0):
        raise ValueError("Percentile must be between 0 and 100")
    sorted_vals = sorted(values)
    k = (len(sorted_vals) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(sorted_vals) - 1)
    d = k - f
    return sorted_vals[f] + (sorted_vals[c] - sorted_vals[f]) * d

class MetricsCollector:
    def __init__(self, name: str):
        self.name = name
        self.samples = []

    def record(self, value: float) -> None:
        self.samples.append(float(value))

    def average(self) -> float:
        if not self.samples:
            return 0.0
        return sum(self.samples) / len(self.samples)

    def count(self) -> int:
        return len(self.samples)
